var fromRep = document.querySelectorAll('.from-rep');
var index = 0, length = fromRep.length;
for ( ; index < length; index++) {
    fromRep[index].style.display = "none";
}
