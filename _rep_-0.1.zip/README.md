# !Rep:

Removing annoying paid content who's prominent on Repubblica.it website.

## Testing

If you want to test yourself and run it in your Firefox, you can build it.

### Install web-ext to debug it and run it.

Run this command in a shell.

```
npm install --global web-ext
```

And then you will be able to use its features.
For more information please go [to Mozilla's getting started](https://developer.mozilla.org/en-US/Add-ons/WebExtensions/Getting_started_with_web-ext).
